﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Framework.Attachments.Infrastructure.Data.Migrations
{
    public partial class Attachments_DBCreation2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attachment_AttachmentType_AttachmentTypeId",
                schema: "Attachment",
                table: "Attachment");

            migrationBuilder.DropForeignKey(
                name: "FK_AttachmentContent_Attachment_AttachmentId",
                schema: "Attachment",
                table: "AttachmentContent");

            migrationBuilder.AddColumn<string>(
                name: "Description",
                schema: "Attachment",
                table: "AttachmentType",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsActive",
                schema: "Attachment",
                table: "AttachmentContent",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                schema: "Attachment",
                table: "AttachmentContent",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                schema: "Attachment",
                table: "AttachmentType",
                keyColumn: "Id",
                keyValue: 100,
                column: "Description",
                value: "the allowed extensions are (jpg,png,jpeg,gif,pdf,doc,docx,xls,xlsx,ppm,ppt,pptx,txt) with maximum 5 MB");

            migrationBuilder.UpdateData(
                schema: "Attachment",
                table: "AttachmentType",
                keyColumn: "Id",
                keyValue: 200,
                column: "Description",
                value: "the allowed extensions are (jpg,png,jpeg) with maximum 5 MB");

            migrationBuilder.UpdateData(
                schema: "Attachment",
                table: "AttachmentType",
                keyColumn: "Id",
                keyValue: 300,
                column: "Description",
                value: "the allowed extensions are (jpg,png,jpeg) with maximum 5 MB");

            migrationBuilder.UpdateData(
                schema: "Attachment",
                table: "AttachmentType",
                keyColumn: "Id",
                keyValue: 400,
                column: "Description",
                value: "the allowed extensions are (xls,xlsx) with maximum 10 MB");

            migrationBuilder.AddForeignKey(
                name: "FK_Attachment_AttachmentType_AttachmentTypeId",
                schema: "Attachment",
                table: "Attachment",
                column: "AttachmentTypeId",
                principalSchema: "Attachment",
                principalTable: "AttachmentType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_AttachmentContent_Attachment_AttachmentId",
                schema: "Attachment",
                table: "AttachmentContent",
                column: "AttachmentId",
                principalSchema: "Attachment",
                principalTable: "Attachment",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Attachment_AttachmentType_AttachmentTypeId",
                schema: "Attachment",
                table: "Attachment");

            migrationBuilder.DropForeignKey(
                name: "FK_AttachmentContent_Attachment_AttachmentId",
                schema: "Attachment",
                table: "AttachmentContent");

            migrationBuilder.DropColumn(
                name: "Description",
                schema: "Attachment",
                table: "AttachmentType");

            migrationBuilder.DropColumn(
                name: "IsActive",
                schema: "Attachment",
                table: "AttachmentContent");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                schema: "Attachment",
                table: "AttachmentContent");

            migrationBuilder.AddForeignKey(
                name: "FK_Attachment_AttachmentType_AttachmentTypeId",
                schema: "Attachment",
                table: "Attachment",
                column: "AttachmentTypeId",
                principalSchema: "Attachment",
                principalTable: "AttachmentType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AttachmentContent_Attachment_AttachmentId",
                schema: "Attachment",
                table: "AttachmentContent",
                column: "AttachmentId",
                principalSchema: "Attachment",
                principalTable: "Attachment",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
