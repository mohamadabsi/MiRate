﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Framework.Attachments.Infrastructure.Data.Migrations
{
    public partial class Attachments_DBCreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "Attachment");

            migrationBuilder.CreateTable(
                name: "AttachmentType",
                schema: "Attachment",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NameAr = table.Column<string>(nullable: true),
                    NameEn = table.Column<string>(nullable: true),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    AllowedFilesExtension = table.Column<string>(nullable: true),
                    Code = table.Column<string>(nullable: true),
                    ImageMaxHeight = table.Column<int>(nullable: true),
                    ImageMaxWidth = table.Column<int>(nullable: true),
                    IsImage = table.Column<bool>(nullable: false),
                    IsMandatory = table.Column<bool>(nullable: false),
                    MaxSizeInMegabytes = table.Column<double>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AttachmentType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Attachment",
                schema: "Attachment",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    IsActive = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    CreatedBy = table.Column<string>(nullable: true),
                    CreatedOn = table.Column<DateTime>(nullable: false),
                    UpdatedBy = table.Column<string>(nullable: true),
                    UpdatedOn = table.Column<DateTime>(nullable: true),
                    ContentType = table.Column<string>(nullable: true),
                    DescriptionAr = table.Column<string>(nullable: true),
                    DescriptionEn = table.Column<string>(nullable: true),
                    Extention = table.Column<string>(nullable: true),
                    FileName = table.Column<string>(nullable: true),
                    FilePath = table.Column<string>(nullable: true),
                    Thumbnail = table.Column<byte[]>(nullable: true),
                    TitleAr = table.Column<string>(nullable: true),
                    TitleEn = table.Column<string>(nullable: true),
                    AttachmentTypeId = table.Column<int>(nullable: false),
                    RequestId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Attachment", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Attachment_AttachmentType_AttachmentTypeId",
                        column: x => x.AttachmentTypeId,
                        principalSchema: "Attachment",
                        principalTable: "AttachmentType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AttachmentContent",
                schema: "Attachment",
                columns: table => new
                {
                    AttachmentId = table.Column<Guid>(nullable: false),
                    Content = table.Column<byte[]>(nullable: true),
                    OldContent = table.Column<byte[]>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AttachmentContent", x => x.AttachmentId);
                    table.ForeignKey(
                        name: "FK_AttachmentContent_Attachment_AttachmentId",
                        column: x => x.AttachmentId,
                        principalSchema: "Attachment",
                        principalTable: "Attachment",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "Attachment",
                table: "AttachmentType",
                columns: new[] { "Id", "AllowedFilesExtension", "Code", "CreatedBy", "CreatedOn", "ImageMaxHeight", "ImageMaxWidth", "IsActive", "IsDeleted", "IsImage", "IsMandatory", "MaxSizeInMegabytes", "NameAr", "NameEn" },
                values: new object[,]
                {
                    { 100, "jpg,png,jpeg,gif,pdf,doc,docx,xls,xlsx,ppm,ppt,pptx,txt", null, null, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null, true, false, false, false, 5.0, null, null },
                    { 200, "jpg,png,jpeg", null, null, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null, true, false, false, false, 5.0, null, null },
                    { 300, "jpg,png,jpeg", null, null, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null, true, false, false, false, 5.0, null, null },
                    { 400, "xls,xlsx", null, null, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), null, null, true, false, false, false, 10.0, null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Attachment_AttachmentTypeId",
                schema: "Attachment",
                table: "Attachment",
                column: "AttachmentTypeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AttachmentContent",
                schema: "Attachment");

            migrationBuilder.DropTable(
                name: "Attachment",
                schema: "Attachment");

            migrationBuilder.DropTable(
                name: "AttachmentType",
                schema: "Attachment");
        }
    }
}
